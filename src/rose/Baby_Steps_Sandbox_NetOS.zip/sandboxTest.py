import os 
import sys
import time
import queue
import threading
import struct
from datetime import datetime
import GreenAgent
import routing 
import signal
from threading import Thread
from multiprocessing import Process
import posix_ipc

STAT_PROTOCOL = 104

class Sandbox:
    #Costructor de la clase 
    #Param: id del node en el cual se esta 
         # Futura bitacora encargada del log del rosado
    #Autor: Carlos Urena 
    def __init__(self,id,bitacora):
        self.stat_queue = queue.Queue() #For the spider request
        self.manager_mailbox = posix_ipc.MessageQueue("/manager", posix_ipc.O_CREAT)
        self.mailbox_dict = {}
        # self.send_mailbox = posix_ipc.MessageQueue("/3", posix_ipc.O_CREAT)

        self.id = id
        self.bitacora = bitacora

        #Se inicializan en set_instances 
        self.g_agent = 0
        self.router = 0

        self.threads = [Thread( target=self.construct_deconstruct, args=()),
                        Thread( target=self.mailbox_manager, args=())]

    #Efecto: Encargado de iniciar los Threads 
    #Autor: Carlos Urena 
    def thread_init(self):
        for x in self.threads:
            x.start()
    
    #Efecto: Metodo publico que usa el dispatcher de rosado para mandar la solicitud a esta funcionalidad
    #Autor: Carlos Urena 
    def stat_store(self,buffer):
        self.stat_queue.put(buffer)

    #Efecto: Encargado de escuchar solitudes de las spider y devolverles su solicitud 
    #Autor: Carlos Urena 
    def mailbox_manager(self):
        while True:
            if self.mailbox_dict: #Solo si el diccionario no esta vacio, si no duerme 
                request = self.manager_mailbox.receive() #Escucha las solicitudes de sus spider
                request_items = request[0].decode().split(',') #Decode() para pasar de binario a texto y split para separar lo enviado 
                if request_items[1] == '0': #solicitud 0, termino
                    

                    #lineas encargadas de cerrar los mailbox 
                    self.manager_mailbox.close()
                    self.manager_mailbox.unlink()
                    self.mailbox_dict[request_items[0]].close()
                    self.mailbox_dict[request_items[0]].unlink()

                    #Encargado de eliminar el elemento del diccionario
                    del self.mailbox_dict[request_items[0]]
                    print("Termino la spider: " + request_items[0])
                    #TODO enviar una signal que esta spider tiene que ser deconstruida 
                else:
                    #Empaqueto la solicitud de la spider en binario 
                    request_paquet = struct.pack("!3B",STAT_PROTOCOL,int(request_items[0]),int(request_items[1]))
                    if(int(request_items[1]) == 3): #si es la solicutud 3 se le pregunta a router por la tabla de adyacencias
                        self.router.stat_queue_store(request_paquet)
                    else:
                        self.g_agent.green_send_store(request_paquet) #Envia a GreenAgent el paquete para que se encarga de llevarlo a verde
        
                    stat_packet = self.stat_queue.get() #pop blocking 
                    stat_packet = stat_packet[1:] #esto le cortaria el protocolo interno 
                    spider_id = str(stat_packet[1]) #Obtengo el id de la spider que es la llave del diccionario
                    stat_packet = stat_packet[2:] #esto le cortaria el id de spider y el id de la solicitud
                    self.mailbox_dict[spider_id].send(stat_packet) #Envio al mailbox que me dice el diccionario 
            else:
                time.sleep(2) #paraqueno este revisando constantemente si se hay mailbox que utilizar

    #Efecto: Encargado de hacer exec a la spider y crear su respectivo mailbox
    #Autor: Carlos Urena
    def construct_deconstruct(self):
        pid = os.fork()
        if pid == 0:
            os.system("python3 ../rose/Spider.py " + "/manager" + " 3 " + self.id)
        else:
            time.sleep(1)
            self.mailbox_dict["3"] = posix_ipc.MessageQueue("/3")

    #Asigna las instacias necesarias de la clase 
    #Autor: Carlos Urena 
    def set_instancies(self,g_agent,router):
        self.g_agent = g_agent
        self.router = router
